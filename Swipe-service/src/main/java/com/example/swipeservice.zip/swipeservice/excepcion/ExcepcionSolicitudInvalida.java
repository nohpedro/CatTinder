package com.example.swipeservice.excepcion;

public class ExcepcionSolicitudInvalida extends RuntimeException {
    public ExcepcionSolicitudInvalida(String mensaje) { super(mensaje); }
}
