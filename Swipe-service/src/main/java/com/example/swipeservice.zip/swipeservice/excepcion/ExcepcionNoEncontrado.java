package com.example.swipeservice.excepcion;

public class ExcepcionNoEncontrado extends RuntimeException {
    public ExcepcionNoEncontrado(String mensaje) { super(mensaje); }
}
