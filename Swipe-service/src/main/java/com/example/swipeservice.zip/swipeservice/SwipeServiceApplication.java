package com.example.swipeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwipeServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(SwipeServiceApplication.class, args);
    }

}
