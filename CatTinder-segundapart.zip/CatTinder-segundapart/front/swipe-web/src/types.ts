export type SwipeResponse = {
    message?: string;
    match?: boolean;
    [key: string]: any;
};
