package com.example.cattinder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatTinderApplicationTests {

    @Test
    void contextLoads() {
    }

}
