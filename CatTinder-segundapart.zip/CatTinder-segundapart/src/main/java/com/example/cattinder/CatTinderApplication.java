package com.example.cattinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatTinderApplication {

    public static void main(String[] args) {
        SpringApplication.run(CatTinderApplication.class, args);
    }

}
